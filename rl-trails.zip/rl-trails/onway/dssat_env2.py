import gymnasium as gym
from gymnasium import spaces
import numpy as np
import pandas as pd
import os
import shutil
import re
from datetime import datetime, timedelta

# Ensure you have DSSATTools installed: pip install dssat-tools
from DSSATTools import (
    crop, WeatherStation, SoilProfile, filex, DSSAT
)
from DSSATTools.filex import IrrigationEvent

class DSSATEnv(gym.Env):
    """
    A custom Gym environment for DSSAT crop simulation focused on irrigation.

    This environment wraps the DSSAT-Python model, allowing a Reinforcement
    Learning agent to interact with the crop simulation on a daily basis.

    **Action Space**: A continuous value representing the amount of irrigation
    water to apply in mm (e.g., any value between 0 and 50).

    **Observation Space (State)**: A 21-element vector containing key biophysical
    and environmental variables derived directly from your `get_state` function.

    **Reward Function**: A composite reward that encourages biomass growth and
    final yield while penalizing water cost, crop stress, and water drainage.
    """
    def __init__(self, action_low=0.0, action_high=50.0):
        super(DSSATEnv, self).__init__()

        # --- 1. Define Action and Observation Spaces ---
        self.action_space = spaces.Box(low=np.array([action_low]), high=np.array([action_high]), dtype=np.float32)
        self.state_size = 21 # Based on the 21 keys in your state dictionary
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(self.state_size,), dtype=np.float32)

        # --- 2. Simulation Configuration ---
        self.max_growth_days = 120
        self.planting_date = datetime(2014, 6, 2)
        self.reward_factors = {
            'GROWTH_FACTOR': 0.01,
            'WATER_COST_FACTOR': 0.1,
            'STRESS_PENALTY_FACTOR': 1.0,
            'DRAINAGE_PENALTY_FACTOR': 0.5,
            'DRYNESS_PENALTY_FACTOR': 0.5,
            'DRYNESS_THRESHOLD': 0.4,
        }

        # --- 3. Initialize DSSAT and Workspace ---
        self._setup_workspace()
        self._load_dssat_configs()
        self.dssat = DSSAT(self.workspace)


    def step(self, action):
        """
        Runs one daily time step of the environment's dynamics.
        """
        self.current_day += 1
        action_value = float(action[0])

        # Add an irrigation event to the schedule if the action is significant
        if action_value > 0.1:
            irr_date = self.planting_date + timedelta(days=self.current_day -1)
            event = IrrigationEvent(idate=irr_date, irop="IR001", irval=action_value)
            self.irrigation_events.append(event)

        # Re-run the simulation with the updated irrigation history
        self.dssat_output = self._run_simulation()

        # Handle simulation failures
        if self.dssat_output is None:
            # End the episode with a high penalty if simulation crashes
            return np.zeros(self.state_size), -200, True, True, {}

        current_state_dict = self._get_state(self.current_day)

        # Handle state extraction failures (e.g., simulation ended prematurely)
        if current_state_dict is None:
            # End the episode with a penalty
            return np.zeros(self.state_size), -100, True, True, {}

        reward = self._calculate_reward(self.previous_state, current_state_dict, action_value)
        
        # Check for termination conditions
        terminated = current_state_dict['phenological_stage'] >= 7
        truncated = self.current_day >= self.max_growth_days
        
        self.previous_state = current_state_dict
        observation = self._normalize_state(current_state_dict)

        return observation, reward, terminated, truncated, {}


    def reset(self, *, seed=None, options=None):
        """
        Resets the environment to an initial state for a new episode.
        """
        super().reset(seed=seed)
        self.current_day = 1
        self.irrigation_events = []
        self.dssat_output = self._run_simulation()

        if self.dssat_output is None:
            raise RuntimeError("Initial DSSAT simulation failed on reset. Check DSSAT setup.")

        self.previous_state = self._get_state(self.current_day)
        observation = self._normalize_state(self.previous_state)
        
        return observation, {}

    # --------------------------------------------------------------------
    # Helper Methods
    # --------------------------------------------------------------------

    def _run_simulation(self):
        """Executes the DSSAT simulation with the current list of irrigation events."""
        irrigation = filex.Irrigation(
            efir=1, idep=30, iame='IR001', table=self.irrigation_events
        )
        try:
            self.dssat.run_treatment(
                field=self.field, cultivar=self.cultivar, planting=self.planting,
                initial_conditions=self.initial_conditions, irrigation=irrigation,
                simulation_controls=self.simulation_controls
            )
            return self.dssat.output_tables
        except Exception as e:
            # This helps debug issues with the DSSAT model itself
            print(f"❌ DSSAT Run Error on day {self.current_day}: {e}")
            return None

    def _get_state(self, current_day):
        """
        Extracts and calculates the state dictionary from DSSAT output.
        This is an adaptation of your provided `get_state` function.
        """
        try:
            # Ensure the requested day exists in the simulation output
            if current_day not in self.dssat_output['PlantGro']['DAS'].values:
                return None
            
            soilwat_df = self.dssat_output['SoilWat']
            
            # --- Pre-computation (run once per simulation) ---
            if 'DRNC_D' not in soilwat_df.columns:
                soilwat_df['DRNC_D'] = soilwat_df['DRNC'].diff().fillna(0)
                soilwat_df['DPREC'] = soilwat_df['PREC'].diff().fillna(soilwat_df['PREC'].iloc[0])
                soilwat_df['Rainfall7DaySum'] = soilwat_df['DPREC'].rolling(window=7, min_periods=1).sum()
                
                # A more robust way to calculate days since last rain
                rain_mask = (soilwat_df['DPREC'] > 0).cumsum()
                soilwat_df['DaysSinceLastRain'] = soilwat_df.groupby(rain_mask).cumcount()

            # --- Data Extraction for current_day ---
            current_weather = self.dssat_output['Weather'].loc[self.dssat_output['Weather']['DAS'] == current_day]
            current_plantgro = self.dssat_output['PlantGro'].loc[self.dssat_output['PlantGro']['DAS'] == current_day]
            current_soilwat = soilwat_df.loc[soilwat_df['DAS'] == current_day]

            # --- Feature Engineering ---
            def get_sw_by_depth(l, h):
                sw_cols = [c for c in soilwat_df.columns if c.startswith("SW") and c.endswith("D") and c[2:-1].isdigit()]
                vals = [current_soilwat[col].iloc[0] for col, depth in zip(sw_cols, self.soil_depths) if l < depth <= h]
                return np.mean(vals) if vals else 0.20

            days_since_last_irrigation = 0
            last_irr_event = None
            for irr in self.irrigation_events:
                if (irr.get('idate') - self.planting_date.date()).days <= self.current_day:
                    last_irr_event = irr
                    days_since_last_irrigation = self.current_day - (irr.get('idate') - self.planting_date.date()).days 
                else:
                    break;
    
            last_irrigation_amount = last_irr_event.get('irval') if last_irr_event else 0

            try:
                forecast_val = soilwat_df[soilwat_df['DAS'] == current_day + 1]['DPREC'].iloc[0][0]
                forecast = float(forecast_val)
            except (IndexError, KeyError):
                forecast = 0.0

            state = {
                'DAP': current_day,
                'days_since_last_rain': current_soilwat['DaysSinceLastRain'].iloc[0],
                'rainfall_7day': current_soilwat['Rainfall7DaySum'].iloc[0],
                'HarvestIndex': current_plantgro['HIAD'].iloc[0],
                'phenological_stage': current_plantgro['GSTD'].iloc[0],
                'leaf_area_index': current_plantgro['LAID'].iloc[0],
                'total_biomass': current_plantgro['CWAD'].iloc[0],
                'soil_water_content_0_30cm': get_sw_by_depth(0, 30),
                'soil_water_content_30_60cm': get_sw_by_depth(30, 60),
                'soil_water_content_60_100cm': get_sw_by_depth(60, 100),
                'available_water_fraction': current_soilwat['SWXD'].iloc[0],
                'water_stress_factor': current_plantgro['WSGD'].iloc[0],
                'temperature_avg': current_weather['TAVD'].iloc[0],
                'solar_radiation': current_weather['SRAD'].iloc[0],
                'last_irrigation_amount': last_irrigation_amount,
                'days_since_last_irrigation': days_since_last_irrigation,
                'cumulative_irrigation': current_soilwat['IRRC'].iloc[0],
                'totalnumberIrrigation': current_soilwat['IR#C'].iloc[0],
                'forecast': forecast,
                'harverst_grain_weight': self.dssat_output['PlantGro']['GWAD'].iloc[-1],
                'daily_drainage': current_soilwat['DRNC_D'].iloc[0]
            }
            return state
        except (IndexError, KeyError) as e:
            print(f"📉 State extraction failed on day {current_day}: {e}")
            return None

    def _calculate_reward(self, prev_state, curr_state, action):
        """Calculates the reward for the current time step."""
        if not prev_state or not curr_state: return -10

        # Positive rewards
        growth = (curr_state['total_biomass'] - prev_state.get('total_biomass', 0)) * self.reward_factors['GROWTH_FACTOR']
        bonus = curr_state['harverst_grain_weight'] / 100 if curr_state['phenological_stage'] >= 7 else 0

        # Negative penalties
        cost = action * self.reward_factors['WATER_COST_FACTOR']
        stress = curr_state['water_stress_factor'] * self.reward_factors['STRESS_PENALTY_FACTOR']
        drainage = curr_state['daily_drainage'] * self.reward_factors['DRAINAGE_PENALTY_FACTOR']
        
        # Dryness penalty
        slll, sdul = self.soil_profile.table[0]['slll'], self.soil_profile.table[0]['sdul']
        pawf = (curr_state['soil_water_content_0_30cm'] - slll) / (sdul - slll) if sdul > slll else 0
        dryness = (self.reward_factors['DRYNESS_THRESHOLD'] - pawf) * self.reward_factors['DRYNESS_PENALTY_FACTOR'] if pawf < self.reward_factors['DRYNESS_THRESHOLD'] else 0

        return float(growth + bonus - (cost + stress + drainage + dryness))

    def _normalize_state(self, state_dict):
        """Normalizes the state dictionary into a flat numpy array for the agent."""
        if state_dict is None: return np.zeros(self.state_size)

        # The order of keys here MUST be consistent
        ordered_keys = sorted(state_dict.keys())
        state_vector = [state_dict[key] for key in ordered_keys]
        return np.array(state_vector, dtype=np.float32)

    def _setup_workspace(self):
        """Creates a dedicated workspace for the simulation run."""
        self.weather_file_path = './dssat_simulation_workspace/CHEN1401.WTH'
        self.soil_file_path = './dssat_simulation_workspace/soil12387893.SOL'
        self.workspace = os.path.join("rl_env_workspace")
        os.makedirs(self.workspace, exist_ok=True)
        shutil.copy(self.weather_file_path, self.workspace)
        shutil.copy(self.soil_file_path, self.workspace)

    def _load_dssat_configs(self):
        """Loads the static DSSAT configuration objects once."""
        soil_id = "SG12387893"
        weather_station = WeatherStation.from_files([self.weather_file_path])
        self.soil_profile = SoilProfile.from_file(soil_id, self.soil_file_path)
        self.cultivar = crop.Sorghum('IB0026')
        self.field = filex.Field(id_field='REALTIME', wsta=weather_station, id_soil=self.soil_profile)
        self.planting = filex.Planting(pdate=self.planting_date, ppop=18, ppoe=18, plrs=45, pldp=5)
        self.soil_depths = [int(layer['slb']) for layer in self.soil_profile.table]
        initial_values = [(depth, 0.20, 1.5, 1.5) for depth in self.soil_depths]
        self.initial_conditions = filex.InitialConditions(
            pcr='SG', icdat=self.planting_date, icres=1300, icren=0.5,
            table=pd.DataFrame(initial_values, columns=['icbl', 'sh2o', 'snh4', 'sno3'])
        )
        self.simulation_controls = filex.SimulationControls(
            general=filex.SCGeneral(sdate=self.planting_date),
            options=filex.SCOptions(water='Y', nitro='N', symbi='N'),
            methods=filex.SCMethods(infil='S'),
            management=filex.SCManagement(irrig='R', ferti='N', resid='N', harvs='M'),
            outputs=filex.SCOutputs(grout='Y', waout='Y', niout='Y', ovvew='Y')
        )
        
import time

if __name__ == "__main__":
    print("🚀 Initializing DSSAT Environment...")
    env = DSSATEnv()
    
    # You can check the environment's spaces
    print(f"Action Space: {env.action_space}")
    print(f"Observation Space Shape: {env.observation_space.shape}")
    
    # Reset the environment to get the first observation
    obs, info = env.reset()
    done = False
    truncated = False
    total_reward = 0
    day = 0
    
    start_time = time.time()
    print("\n--- Running a Test Episode with Random Actions ---")

    while not done and not truncated:
        day += 1
        # Take a random action from the continuous action space
        action = env.action_space.sample()
        
        # Perform the action
        obs, reward, done, truncated, info = env.step(action)
        
        total_reward += reward
        
        print(f"Day: {day:03d} | "
              f"Action: {action[0]:5.2f} mm | "
              f"Reward: {reward:6.2f} | "
              f"Total Reward: {total_reward:8.2f}")
              
        if done:
            print("\n--- Episode Terminated (Harvest) ---")
        if truncated:
            print("\n--- Episode Truncated (Max Days Reached) ---")
            
    end_time = time.time()
    print(f"\nFinal Total Reward: {total_reward:.2f}")
    print(f"Total Episode Time: {end_time - start_time:.2f} seconds")
    print(f"Average Time per Day: {(end_time - start_time) / day:.3f} seconds")