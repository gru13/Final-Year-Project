# import requests
# import pandas as pd
# import numpy as np
# import os
# from datetime import datetime
# from collections import defaultdict
# from typing import Optional, Dict

# def get_o3(api_key: str, lat: float, lon: float, start_str: str, end_str: str) -> pd.DataFrame:
#     """Fetches O3 data from OpenWeatherMap API."""
#     if not api_key or api_key == "YOUR_API_KEY_HERE":
#         print("Warning: OpenWeatherMap API key is missing.")
#         return pd.DataFrame()
    
#     print("Fetching OpenWeatherMap O3 data...")
#     try:
#         start_ts = int(pd.to_datetime(start_str).timestamp())
#         end_ts = int(pd.to_datetime(end_str).replace(hour=23, minute=59).timestamp())
#         api_url = f"http://api.openweathermap.org/data/2.5/air_pollution/history?lat={lat}&lon={lon}&start={start_ts}&end={end_ts}&appid={api_key}"
        
#         response = requests.get(api_url, timeout=30)
#         response.raise_for_status()
#         data = response.json().get('list', [])

#         if not data:
#             print("...O3 data fetched, but no records returned for the period.")
#             return pd.DataFrame()

#         daily_data = defaultdict(list)
#         for entry in data:
#             local_date = datetime.fromtimestamp(entry['dt']).date()
#             daily_data[local_date].append(entry['components'].get('o3', 0))

#         records = [{'date': date, 'ozon7': np.mean(vals)} for date, vals in sorted(daily_data.items())]
#         df = pd.DataFrame(records)
#         df['date'] = pd.to_datetime(df['date'])
#         print("...O3 data fetched successfully.")
#         return df
#     except requests.exceptions.RequestException as e:
#         print(f"Error fetching O3 data: {e}. Proceeding without it.")
#         return pd.DataFrame()

# def _fetch_nasa_weather(lat: float, lon: float, start: str, end: str) -> pd.DataFrame:
#     """Fetches NASA POWER weather data."""
#     print("Fetching NASA POWER data...")
#     try:
#         url = "https://power.larc.nasa.gov/api/temporal/daily/point"
#         params = {
#             "start": pd.to_datetime(start).strftime("%Y%m%d"),
#             "end": pd.to_datetime(end).strftime("%Y%m%d"),
#             "latitude": lat, "longitude": lon, "community": "AG",
#             "parameters": "ALLSKY_SFC_SW_DWN,T2M_MAX,T2M_MIN,T2MDEW,PRECTOTCORR,WS2M,RH2M,EVPTRNS",
#             "format": "JSON"
#         }
#         response = requests.get(url, params=params, timeout=30)
#         response.raise_for_status()
        
#         data = response.json()["properties"]["parameter"]
#         df = pd.DataFrame(data).reset_index().rename(columns={"index": "date"})
#         df["date"] = pd.to_datetime(df["date"], format="%Y%m%d")
#         df = df.replace([-999, -99], np.nan)
#         df = df.rename(columns={
#             "ALLSKY_SFC_SW_DWN": "srad", "T2M_MAX": "tmax", "T2M_MIN": "tmin",
#             "T2MDEW": "dewp", "PRECTOTCORR": "rain", "WS2M": "wind",
#             "RH2M": "rhum", "EVPTRNS": "evap"
#         })
#         print("...NASA data fetched successfully.")
#         return df
#     except requests.exceptions.RequestException as e:
#         print(f"FATAL: Error fetching NASA POWER data: {e}")
#         return pd.DataFrame()

# def create_weather_file(
#     api_key: str,
#     lat: float,
#     lon: float,
#     start_date: str,
#     end_date: str,
#     site_name: str = "SITE",
#     insi: str = "XXXX",
#     elev: Optional[float] = None
# ) -> Optional[pd.DataFrame]:
#     """
#     Fetches weather data and writes a standard DSSAT-compatible .WTH file.
#     """
#     weather_df = _fetch_nasa_weather(lat, lon, start_date, end_date)
#     if weather_df.empty:
#         print("Could not fetch base weather data from NASA POWER. Aborting.")
#         return None

#     o3_df = get_o3(api_key, lat, lon, start_date, end_date)
    
#     df = weather_df
#     if not o3_df.empty:
#         df = pd.merge(df, o3_df, on='date', how='left')

#     if 'ozon7' in df.columns:
#         df['ozon7'] = df['ozon7'].fillna(50.0)
#     else:
#         df['ozon7'] = 50.0
    
#     df['dco2'] = 421.0

#     df["wind"] = df["wind"] * 86.4
#     df["month"] = df["date"].dt.month
#     monthly_srad_avg = df.groupby("month")["srad"].mean().to_dict()
#     df["par"] = df["month"].map(monthly_srad_avg)
#     df["vapr"] = 0.6108 * np.exp((17.27 * df["dewp"]) / (df["dewp"] + 237.3))
    
#     # --- CHANGE #1: Revert to the standard YRDOY (YYJJJ) format ---
#     df["YRDOY"] = df["date"].dt.strftime("%y%j")
    
#     tav = ((df["tmax"] + df["tmin"]) / 2).mean()
#     amp = (df["tmax"].mean() - df["tmin"].mean())

#     df_out = df.fillna(-99)
    
#     # --- CHANGE #2: Update the list of columns to use YRDOY ---
#     output_cols = ["YRDOY","srad","tmax","tmin","rain","rhum","wind","dewp","par","vapr","dco2","ozon7","evap"]
    
#     output_dir = "weather"
#     os.makedirs(output_dir, exist_ok=True)
    
#     year_2_digit = pd.to_datetime(start_date).strftime('%y')
#     wth_file = os.path.join(output_dir, f"{insi}{year_2_digit}01.WTH")
#     print(f"\nWriting weather data to: {wth_file}")

#     with open(wth_file, "w") as f:
#         f.write(f"*WEATHER DATA : {site_name},NASA\n\n")
#         f.write("@ INSI      LAT     LONG    ELEV   TAV   AMP REFHT WNDHT   CCO2\n")
#         f.write(f"  {insi:<4s}  {lat:7.3f} {lon:7.3f} {elev if elev else -99:5.1f} {tav:5.1f} {amp:5.1f}   2.0   2.0 {df['dco2'].mean():6.1f}\n\n")
#         f.write("@DATE  SRAD  TMAX  TMIN  RAIN  RHUM  WIND  DEWP   PAR  VAPR   DCO2  OZON7  EVAP\n")
        
#         # --- CHANGE #3: Write the date as a 7-digit integer ---
#         for _, row in df_out[output_cols].iterrows():
#             f.write(f"{int(row.YRDOY):7d} {row.srad:5.1f} {row.tmax:5.1f} {row.tmin:5.1f} "
#                     f"{row.rain:5.1f} {row.rhum:5.1f} {row.wind:5.1f} {row.dewp:5.1f} "
#                     f"{row.par:6.1f} {row.vapr:5.2f} {row.dco2:6.1f} {int(row.ozon7):6d} {row.evap:5.1f}\n")
    
#     print("✅ File created successfully.")
#     return df_out

# if __name__ == "__main__":
#     API_KEY = "eddbc7c0c9e63e225934add809624c6e" # Replace with your key if needed
    
#     LATITUDE = 13.08
#     LONGITUDE = 80.27
#     START_DATE = "2025-01-01"
#     END_DATE = "2025-03-31"
    
#     final_data = create_weather_file(
#         api_key=API_KEY,
#         lat=LATITUDE,
#         lon=LONGITUDE,
#         start_date=START_DATE,
#         end_date=END_DATE,
#         site_name="CHENNAI",
#         insi="CHEN",
#         elev=6.0
#     )
import requests
import pandas as pd
import numpy as np
import os
from datetime import datetime
from collections import defaultdict
from typing import Optional, Dict

def get_o3(api_key: str, lat: float, lon: float, start_str: str, end_str: str) -> pd.DataFrame:
    """Fetches O3 data from OpenWeatherMap API."""
    if not api_key or api_key == "YOUR_API_KEY_HERE":
        print("Warning: OpenWeatherMap API key is missing.")
        return pd.DataFrame()
    
    print("Fetching OpenWeatherMap O3 data...")
    try:
        start_ts = int(pd.to_datetime(start_str).timestamp())
        end_ts = int(pd.to_datetime(end_str).replace(hour=23, minute=59).timestamp())
        api_url = f"http://api.openweathermap.org/data/2.5/air_pollution/history?lat={lat}&lon={lon}&start={start_ts}&end={end_ts}&appid={api_key}"
        
        response = requests.get(api_url, timeout=30)
        response.raise_for_status()
        data = response.json().get('list', [])

        if not data:
            print("...O3 data fetched, but no records returned for the period.")
            return pd.DataFrame()

        daily_data = defaultdict(list)
        for entry in data:
            local_date = datetime.fromtimestamp(entry['dt']).date()
            daily_data[local_date].append(entry['components'].get('o3', 0))

        records = [{'date': date, 'ozon7': np.mean(vals)} for date, vals in sorted(daily_data.items())]
        df = pd.DataFrame(records)
        df['date'] = pd.to_datetime(df['date'])
        print("...O3 data fetched successfully.")
        return df
    except requests.exceptions.RequestException as e:
        print(f"Error fetching O3 data: {e}. Proceeding without it.")
        return pd.DataFrame()

def _fetch_nasa_weather(lat: float, lon: float, start: str, end: str) -> pd.DataFrame:
    """Fetches NASA POWER weather data."""
    print("Fetching NASA POWER data...")
    try:
        url = "https://power.larc.nasa.gov/api/temporal/daily/point"
        params = {
            "start": pd.to_datetime(start).strftime("%Y%m%d"),
            "end": pd.to_datetime(end).strftime("%Y%m%d"),
            "latitude": lat, "longitude": lon, "community": "AG",
            "parameters": "ALLSKY_SFC_SW_DWN,T2M_MAX,T2M_MIN,T2MDEW,PRECTOTCORR,WS2M,RH2M,EVPTRNS",
            "format": "JSON"
        }
        response = requests.get(url, params=params, timeout=30)
        response.raise_for_status()
        
        data = response.json()["properties"]["parameter"]
        df = pd.DataFrame(data).reset_index().rename(columns={"index": "date"})
        df["date"] = pd.to_datetime(df["date"], format="%Y%m%d")
        df = df.replace([-999, -99], np.nan)
        df = df.rename(columns={
            "ALLSKY_SFC_SW_DWN": "srad", "T2M_MAX": "tmax", "T2M_MIN": "tmin",
            "T2MDEW": "dewp", "PRECTOTCORR": "rain", "WS2M": "wind",
            "RH2M": "rhum", "EVPTRNS": "evap"
        })
        print("...NASA data fetched successfully.")
        return df
    except requests.exceptions.RequestException as e:
        print(f"FATAL: Error fetching NASA POWER data: {e}")
        return pd.DataFrame()

def create_weather_file(
    api_key: str,
    lat: float,
    lon: float,
    start_date: str,
    end_date: str,
    site_name: str = "SITE",
    insi: str = "XXXX",
    elev: Optional[float] = None
) -> Optional[pd.DataFrame]:
    """
    Fetches weather data and writes a standard DSSAT-compatible .WTH file.
    """
    weather_df = _fetch_nasa_weather(lat, lon, start_date, end_date)
    if weather_df.empty:
        print("Could not fetch base weather data from NASA POWER. Aborting.")
        return None

    o3_df = get_o3(api_key, lat, lon, start_date, end_date)
    
    df = weather_df
    if not o3_df.empty:
        df = pd.merge(df, o3_df, on='date', how='left')

    if 'ozon7' in df.columns:
        df['ozon7'] = df['ozon7'].fillna(50.0)
    else:
        df['ozon7'] = 50.0
    
    df['dco2'] = 421.0

    df["wind"] = df["wind"] * 86.4
    df["month"] = df["date"].dt.month
    monthly_srad_avg = df.groupby("month")["srad"].mean().to_dict()
    df["par"] = df["month"].map(monthly_srad_avg)
    df["vapr"] = 0.6108 * np.exp((17.27 * df["dewp"]) / (df["dewp"] + 237.3))
    
    # --- CHANGE #1: Revert to the standard YRDOY (YYJJJ) format ---
    df["YRDOY"] = df["date"].dt.strftime("%y%j")
    
    tav = ((df["tmax"] + df["tmin"]) / 2).mean()
    amp = (df["tmax"].mean() - df["tmin"].mean())

    df_out = df.fillna(-99)
    
    # --- CHANGE #2: Update the list of columns to use YRDOY ---
    output_cols = ["YRDOY","srad","tmax","tmin","rain","rhum","wind","dewp","par","vapr","dco2","ozon7","evap"]
    
    output_dir = "weather"
    os.makedirs(output_dir, exist_ok=True)
    
    year_2_digit = pd.to_datetime(start_date).strftime('%y')
    wth_file = os.path.join(output_dir, f"{insi}{year_2_digit}01.WTH")
    print(f"\nWriting weather data to: {wth_file}")

    with open(wth_file, "w") as f:
        f.write(f"*WEATHER DATA : {site_name},NASA\n\n")
        f.write("@ INSI      LAT     LONG    ELEV   TAV   AMP REFHT WNDHT   CCO2\n")
        f.write(f"  {insi:<4s}  {lat:7.3f} {lon:7.3f} {elev if elev else -99:5.1f} {tav:5.1f} {amp:5.1f}   2.0   2.0 {df['dco2'].mean():6.1f}\n\n")
        f.write("@DATE  SRAD  TMAX  TMIN  RAIN  RHUM  WIND  DEWP   PAR  VAPR   DCO2  OZON7  EVAP\n")
        
        # --- CHANGE #3: Write the date as a 7-digit integer ---
        for _, row in df_out[output_cols].iterrows():
            f.write(f"{int(row.YRDOY):7d} {row.srad:5.1f} {row.tmax:5.1f} {row.tmin:5.1f} "
                    f"{row.rain:5.1f} {row.rhum:5.1f} {row.wind:5.1f} {row.dewp:5.1f} "
                    f"{row.par:6.1f} {row.vapr:5.2f} {row.dco2:6.1f} {int(row.ozon7):6d} {row.evap:5.1f}\n")
    
    print("✅ File created successfully.")
    return df_out

if __name__ == "__main__":
    API_KEY = "eddbc7c0c9e63e225934add809624c6e" # Replace with your key if needed
    
    LATITUDE = 13.08
    LONGITUDE = 80.27
    START_DATE = "2025-01-01"
    END_DATE = "2025-03-31"
    
    final_data = create_weather_file(
        api_key=API_KEY,
        lat=LATITUDE,
        lon=LONGITUDE,
        start_date=START_DATE,
        end_date=END_DATE,
        site_name="CHENNAI",
        insi="CHEN",
        elev=6.0
    )