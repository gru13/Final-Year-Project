import numpy as np
import random
from collections import deque, namedtuple
import os
import shutil
from datetime import datetime, timedelta
import pandas as pd
import re
import time

from DSSATTools import (
    crop, WeatherStation, SoilProfile, filex, DSSAT
)
from DSSATTools.filex import IrrigationEvent

# --- [CELL 1 & 2] - INITIAL SETUP & CONSTANTS (from your notebook) ---
WEATHER_FILE = r'./dssat_simulation_workspace/CHEN1401.WTH'
SOIL_ID = "SG12387893"
SOIL_FILE = r'./dssat_simulation_workspace/soil12387893.SOL'
PLANTING_DATE = datetime(2014, 6, 2)
MAX_GROWTH_DAYS = 120 # Set a maximum episode length

reward_factors = {
    'GROWTH_FACTOR': 0.01,
    'WATER_COST_FACTOR': 2.0,
    'STRESS_PENALTY_FACTOR': 1.0,
    'DRAINAGE_PENALTY_FACTOR': 0.5,
    'DRYNESS_PENALTY_FACTOR': 0.5,
    'DRYNESS_THRESHOLD': 0.4,
}

# --- [CELL 3] - CORE SIMULATION OBJECTS (from your notebook) ---
weather_station = WeatherStation.from_files([WEATHER_FILE])

soil_profile = SoilProfile.from_file(SOIL_ID, SOIL_FILE)

cultivar = crop.Sorghum('IB0026')

field = filex.Field(id_field='REALTIME', wsta=weather_station, id_soil=soil_profile)

planting = filex.Planting(pdate=PLANTING_DATE, ppop=18, ppoe=18, plrs=45, pldp=5)

soil_depths = [int(layer['slb']) for layer in soil_profile.table]

initial_values_table = [(depth, 0.20, 1.5, 1.5) for depth in soil_depths]

initial_conditions = filex.InitialConditions(
    pcr='SG', icdat=PLANTING_DATE, icres=1300, icren=0.5,
    table=pd.DataFrame(initial_values_table, columns=['icbl', 'sh2o', 'snh4', 'sno3'])
)

simulation_controls = filex.SimulationControls(
    general=filex.SCGeneral(sdate=PLANTING_DATE),
    options=filex.SCOptions(water='Y', nitro='N', symbi='N'),
    methods=filex.SCMethods(infil='S'),
    management=filex.SCManagement(irrig='R', ferti='N', resid='N', harvs='M'),
    outputs=filex.SCOutputs(grout='Y', waout='Y', niout='Y', ovvew='Y')
)

# --- ENVIRONMENT CLASS ---
class DSSATEnv:
    def __init__(self):
        self.action_space = [0, 10, 20] # 0mm, 10mm, 20mm
        self.state_size = 20 # Number of features in the state vector
        self.workspace = os.path.join("rl_workspace")
        os.makedirs(self.workspace, exist_ok=True)
        shutil.copy(WEATHER_FILE, self.workspace)
        shutil.copy(SOIL_FILE, self.workspace)
        self.dssat = DSSAT(self.workspace)
        self.reset()

    def reset(self):
        self.current_day = 1
        self.irrigation_events = []
        self.dssat_output = self._run_simulation()
        
        if self.dssat_output is None or 'PlantGro' not in self.dssat_output or self.dssat_output['PlantGro'].empty:
             print("⚠️ Warning: Reset failed to generate valid simulation output. Retrying.")
             return np.zeros(self.state_size)

        self.previous_state = self._get_state(self.current_day)
        return self._normalize_state(self.previous_state)

    def step(self, action_index):
        action_value = self.action_space[action_index]
        self.current_day += 1

        if action_value > 0:
            irr_date = PLANTING_DATE + timedelta(days=self.current_day)
            event = IrrigationEvent(idate=irr_date, irop="IR001", irval=action_value)
            self.irrigation_events.append(event)

        self.dssat_output = self._run_simulation()

        if self.dssat_output is None:
            return np.zeros(self.state_size), -100, True, {}

        current_state = self._get_state(self.current_day)

        if current_state is None:
            return np.zeros(self.state_size), -100, True, {}
            
        reward = self._calculate_reward(self.previous_state, current_state, action_value)
        
        done = current_state['phenological_stage'] >= 7 or self.current_day >= MAX_GROWTH_DAYS

        self.previous_state = current_state
        
        return self._normalize_state(current_state), reward, done, {}

    def _run_simulation(self):
        irrigation = filex.Irrigation(
            efir=1, idep=30, iame='IR001',
            table=self.irrigation_events
        )
        try:
            results = self.dssat.run_treatment(
                field=field, cultivar=cultivar, planting=planting,
                initial_conditions=initial_conditions, irrigation=irrigation,
                simulation_controls=simulation_controls
            )
            return self.dssat.output_tables
        except Exception as e:
            print(f"❌ DSSAT Run Error on day {self.current_day}: {e}")
            return None

    # --- [CELL 6] - GET_STATE FUNCTION (UPDATED FROM YOUR NOTEBOOK) ---
    def _get_state(self, current_day):
        try:
            if current_day not in self.dssat_output['PlantGro']['DAS'].values:
                return None
                
            # --- Pre-computation of daily metrics (run only once per simulation output) ---
            soilwat_df = self.dssat_output['SoilWat']
            if 'DRNC_D' not in soilwat_df.columns:
                soilwat_df['DRNC_D'] = soilwat_df['DRNC'].diff().fillna(0)
            
            if 'DPREC' not in soilwat_df.columns:
                # Calculate daily precipitation from cumulative
                soilwat_df['DPREC'] = soilwat_df['PREC'].diff().fillna(soilwat_df['PREC'].iloc[0])
                
                # Calculate 7-day rolling sum of rainfall
                soilwat_df['Rainfall7DaySum'] = soilwat_df['DPREC'].rolling(window=7, min_periods=1).sum()
                
                # Calculate Days Since Last Rain
                days_since_rain_list = []
                counter = 0
                for rain_amount in soilwat_df['DPREC']:
                    if rain_amount > 0:
                        counter = 0
                    else:
                        counter += 1
                    days_since_rain_list.append(counter)
                soilwat_df['DaysSinceLastRain'] = days_since_rain_list

            # --- Data Extraction ---
            current_plantgro = self.dssat_output['PlantGro'][self.dssat_output['PlantGro']['DAS'] == current_day]
            current_soilwat = soilwat_df[soilwat_df['DAS'] == current_day]
            current_weather = self.dssat_output['Weather'][self.dssat_output['Weather']['DAS'] == current_day]
            
            # --- Feature Engineering ---
            sw_cols = [col for col in self.dssat_output['SoilWat'].columns if re.match(r'^SW\d+D?$', col)]
            
            def get_sw_by_depth(l, h):
                results = [current_soilwat[a].iloc[0] for a, b in zip(sw_cols, soil_depths) if l < b <= h]
                return sum(results) / len(results) if results else 0.20
            
            
            days_since_last_irrigation = 0
            last_irr_event = None
            for irr in self.irrigation_events:
                if (irr.get('idate') - PLANTING_DATE.date()).days <= self.current_day:
                    last_irr_event = irr
                    days_since_last_irrigation = self.current_day - (irr.get('idate') - PLANTING_DATE.date()).days 
                else:
                    break;
    
            last_irrigation_amount = last_irr_event.get('irval') if last_irr_event else 0

            # Forecast for the next day's precipitation
            try:
                forecast_val = soilwat_df[soilwat_df['DAS'] == current_day + 1]['DPREC'].iloc[0][0]
                forecast = float(forecast_val)
            except (IndexError, KeyError):
                forecast = 0.0

            state = {
                'DAP': current_day,
                'phenological_stage': current_plantgro['GSTD'].iloc[0],
                'leaf_area_index': current_plantgro['LAID'].iloc[0],
                'total_biomass': current_plantgro['CWAD'].iloc[0],
                'soil_water_content_0_30cm': get_sw_by_depth(0, 30),
                'soil_water_content_30_60cm': get_sw_by_depth(30, 60),
                'soil_water_content_60_100cm': get_sw_by_depth(60, 100),
                'available_water_fraction': current_soilwat['SWXD'].iloc[0],
                'water_stress_factor': current_plantgro['WSGD'].iloc[0],
                'temperature_avg': current_weather['TAVD'].iloc[0],
                'solar_radiation': current_weather['SRAD'].iloc[0],
                'last_irrigation_amount': last_irrigation_amount,
                'days_since_last_irrigation': days_since_last_irrigation,
                'cumulative_irrigation': current_soilwat['IRRC'].iloc[0],
                'harverst_grain_weight': self.dssat_output['PlantGro']['GWAD'].iloc[-1],
                'daily_drainage': current_soilwat['DRNC_D'].iloc[0],
                'HarvestIndex': current_plantgro['HIAD'].iloc[0],
                'days_since_last_rain': current_soilwat['DaysSinceLastRain'].iloc[0],
                'rainfall_7day': current_soilwat['Rainfall7DaySum'].iloc[0],
                'forecast': forecast
            }
            return state

        except (IndexError, KeyError) as e:
            print(f"📉 State extraction failed on day {current_day}: {e}")
            return None

    def _calculate_reward(self, previous_state, current_state, action):
        if not previous_state or not current_state:
            return -10

        prev_biomass = previous_state.get('total_biomass', 0)
        daily_growth_reward = (current_state['total_biomass'] - prev_biomass) * reward_factors['GROWTH_FACTOR']
        
        final_harvest_bonus = current_state['harverst_grain_weight'] / 100 if current_state['phenological_stage'] >= 7 else 0

        water_cost_penalty = (action / 10) * reward_factors['WATER_COST_FACTOR']

        water_stress_penalty = current_state['water_stress_factor'] * reward_factors['STRESS_PENALTY_FACTOR']
        drainage_penalty = current_state['daily_drainage'] * reward_factors['DRAINAGE_PENALTY_FACTOR']

        dryness_penalty = 0
        slll_top, sdul_top = soil_profile.table[0]['slll'], soil_profile.table[0]['sdul']
        if sdul_top > slll_top:
            pawf = (current_state['soil_water_content_0_30cm'] - slll_top) / (sdul_top - slll_top)
            if pawf < reward_factors['DRYNESS_THRESHOLD']:
                dryness_penalty = (reward_factors['DRYNESS_THRESHOLD'] - pawf) * reward_factors['DRYNESS_PENALTY_FACTOR']
        
        total_reward = (daily_growth_reward + final_harvest_bonus) - \
                       (water_cost_penalty + water_stress_penalty + drainage_penalty + dryness_penalty)
        
        return float(total_reward)

    def _normalize_state(self, state):
        if state is None:
            return np.zeros(self.state_size)
            
        state_vector = np.array([
            state['DAP'] / 150.0,
            state['phenological_stage'] / 7.0,
            state['leaf_area_index'] / 6.0,
            state['total_biomass'] / 15000.0,
            state['soil_water_content_0_30cm'] / 0.5,
            state['soil_water_content_30_60cm'] / 0.5,
            state['soil_water_content_60_100cm'] / 0.5,
            state['available_water_fraction'] / 100.0,
            state['water_stress_factor'],
            state['temperature_avg'] / 40.0,
            state['solar_radiation'] / 30.0,
            state['last_irrigation_amount'] / 50.0,
            state['days_since_last_irrigation'] / 30.0,
            state['cumulative_irrigation'] / 500.0,
            state['harverst_grain_weight'] / 5000.0,
            state['daily_drainage'] / 10.0,
            state['HarvestIndex'],
            state['days_since_last_rain'] / 30.0,
            state['rainfall_7day'] / 100.0,
            state['forecast'] / 50.0
        ], dtype=np.float32)
        return state_vector
    

# --- PASTE THE ENTIRE DSSATEnv CLASS CODE HERE ---
# (The long code block from the previous response, starting with "import torch"
# and ending with the "_normalize_state" function, should be placed here.)

# --- DRIVER SCRIPT ---
if __name__ == "__main__":
    print("🚀 Initializing DSSAT Environment for a test run...")
    env = DSSATEnv()

    # Reset the environment to get the starting state
    state = env.reset()
    total_reward = 0
    done = False
    day = 0

    start_time = time.time()

    print("\n--- Starting Test Episode with Random Actions ---")
    while not done:
        day += 1
        # Choose a random action (0, 1, or 2) corresponding to [0, 10, 20] mm
        action_index = np.random.randint(0, len(env.action_space))

        # Perform the action in the environment
        next_state, reward, done, _ = env.step(action_index)

        total_reward += reward

        print(f"Day: {day:03d} | "
              f"Action: {env.action_space[action_index]:2d}mm | "
              f"Reward: {reward:6.2f} | "
              f"Total Reward: {total_reward:8.2f} | "
              f"Done: {done}")

        # Update the state for the next iteration
        state = next_state

        # Break if something goes wrong to prevent an infinite loop
        if day >= MAX_GROWTH_DAYS:
            print("Reached maximum simulation days.")
            break

    end_time = time.time()
    print("\n--- Test Episode Finished ---")
    print(f"Total simulated days: {day}")
    print(f"Final total reward: {total_reward:.2f}")
    print(f"Total execution time: {end_time - start_time:.2f} seconds")
    print(f"Average time per day/step: {(end_time - start_time) / day:.2f} seconds")