# # import requests
# # import datetime

# # def get_rain_forecast_by_coords(api_key: str, latitude: float, longitude: float):
# #     """
# #     Fetches the 5-day weather forecast for a specific lat/lon 
# #     and checks for rain on the next day.
# #     """
# #     # Base URL for the 5-day/3-hour forecast API
# #     base_url = "http://api.openweathermap.org/data/2.5/forecast"
    
# #     # Parameters for the API request using latitude and longitude
# #     params = {
# #         'lat': latitude,
# #         'lon': longitude,
# #         'appid': api_key,
# #         'units': 'metric'  # Use 'imperial' for Fahrenheit
# #     }
    
# #     try:
# #         # Make the API request
# #         response = requests.get(base_url, params=params)
# #         response.raise_for_status()  # This will raise an error for bad responses (4xx or 5xx)
        
# #         # Parse the JSON data from the response
# #         forecast_data = response.json()
        
# #         # Get location name from API response for user-friendly output
# #         location_name = forecast_data.get('city', {}).get('name', f"Lat/Lon: {latitude},{longitude}")

# #         # Get tomorrow's date
# #         tomorrow = (datetime.date.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        
# #         print(f"Checking for rain in {location_name} on {tomorrow}...")
        
# #         rain_found = False
# #         # Loop through the list of 3-hour forecast intervals
# #         for forecast in forecast_data['list']:
# #             # Check if the forecast date matches tomorrow's date
# #             if tomorrow in forecast['dt_txt']:
# #                 # The 'pop' key is the Probability of Precipitation (from 0 to 1)
# #                 pop = forecast.get('pop', 0)
                
# #                 if pop > 0:
# #                     rain_found = True
# #                     forecast_time = forecast['dt_txt'].split(' ')[1]
# #                     weather_description = forecast['weather'][0]['description']
# #                     # Convert probability to percentage
# #                     rain_chance = pop * 100
                    
# #                     print(f" -> At {forecast_time}: Chance of rain is {rain_chance:.0f}%. Forecast: {weather_description}.")

# #         if not rain_found:
# #             print("No rain is expected tomorrow. ☀️")

# #     except requests.exceptions.RequestException as e:
# #         print(f"Error fetching data: {e}")
# #     except KeyError:
# #         print("Error parsing data. Your API key or coordinates might be incorrect.")

# # # --- Main execution ---
# # if __name__ == "__main__":
# #     # ⚠️ IMPORTANT: Replace with your actual API key and desired coordinates
# #     API_KEY = "eddbc7c0c9e63e225934add809624c6e"
    
# #     # Example coordinates for Mumbai, India
# #     LATITUDE = 19.0760
# #     LONGITUDE = 72.8777
    
# #     get_rain_forecast_by_coords(API_KEY, LATITUDE, LONGITUDE)
# import requests
# import datetime

# def get_rain_forecast_by_coords(api_key: str, latitude: float, longitude: float):
#     """
#     Fetches the 5-day weather forecast for a specific lat/lon 
#     and checks for rain volume (mm) on the next day.
#     """
#     base_url = "http://api.openweathermap.org/data/2.5/forecast"
    
#     params = {
#         'lat': latitude,
#         'lon': longitude,
#         'appid': api_key,
#         'units': 'metric'
#     }
    
#     try:
#         response = requests.get(base_url, params=params)
#         response.raise_for_status()
        
#         forecast_data = response.json()
        
#         location_name = forecast_data.get('city', {}).get('name', f"Lat/Lon: {latitude},{longitude}")
#         tomorrow = (datetime.date.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        
#         print(f"Checking for rain in {location_name} on {tomorrow}...")
        
#         rain_found = False
#         for forecast in forecast_data['list']:
#             if tomorrow in forecast['dt_txt']:
#                 # Safely get the rain volume in mm for the last 3 hours.
#                 # Defaults to 0 if 'rain' or '3h' keys don't exist.
#                 rain_mm = forecast.get('rain', {}).get('3h', 0)

#                 if rain_mm > 0:
#                     rain_found = True
#                     forecast_time = forecast['dt_txt'].split(' ')[1]
#                     weather_description = forecast['weather'][0]['description']
                    
#                     # Also get probability of precipitation for context
#                     pop = forecast.get('pop', 0)
#                     rain_chance = pop * 100
                    
#                     print(f" -> At {forecast_time}: {rain_mm} mm of rain expected. (Chance: {rain_chance:.0f}%, Forecast: {weather_description})")

#         if not rain_found:
#             print("No measurable rain is expected tomorrow. ☀️")

#     except requests.exceptions.RequestException as e:
#         print(f"Error fetching data: {e}")
#     except KeyError:
#         print("Error parsing data. Your API key or coordinates might be incorrect.")

# # --- Main execution ---
# if __name__ == "__main__":
#     # ⚠️ IMPORTANT: Replace with your actual API key and desired coordinates
#     API_KEY = "eddbc7c0c9e63e225934add809624c6e"
    
#     # Example coordinates for Mumbai, India
#     LATITUDE = 19.0760
#     LONGITUDE = 72.8777
    
#     get_rain_forecast_by_coords(API_KEY, LATITUDE, LONGITUDE)
import requests
import datetime
from typing import Union

def get_rain_forecast(api_key: str, latitude: float, longitude: float, desc: bool = True) -> Union[str, float]:
    """
    Fetches the next day's rain forecast for a specific lat/lon.

    Args:
        api_key: Your OpenWeatherMap API key.
        latitude: The latitude of the location.
        longitude: The longitude of the location.
        desc: If True, returns a formatted string description.
              If False, returns the total rain in mm as a float.

    Returns:
        A string or a float depending on the 'desc' parameter.
    """
    base_url = "http://api.openweathermap.org/data/2.5/forecast"
    params = {
        'lat': latitude,
        'lon': longitude,
        'appid': api_key,
        'units': 'metric'
    }
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()
        
        forecast_data = response.json()
        
        location_name = forecast_data.get('city', {}).get('name', f"Lat/Lon: {latitude},{longitude}")
        tomorrow = (datetime.date.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        
        descriptions = []
        total_rain_mm = 0.0

        for forecast in forecast_data['list']:
            if tomorrow in forecast['dt_txt']:
                rain_mm = forecast.get('rain', {}).get('3h', 0)
                total_rain_mm += rain_mm

                if rain_mm > 0:
                    forecast_time = forecast['dt_txt'].split(' ')[1]
                    weather_description = forecast['weather'][0]['description']
                    pop = forecast.get('pop', 0) * 100
                    desc_line = (f" -> At {forecast_time}: {rain_mm} mm of rain expected. "
                                 f"(Chance: {pop:.0f}%, Forecast: {weather_description})")
                    descriptions.append(desc_line)

        # Return value based on the 'desc' parameter
        if not desc:
            return round(total_rain_mm, 2)
        else:
            if not descriptions:
                return f"No measurable rain is expected for {location_name} tomorrow. ☀️"
            else:
                header = f"Rain forecast for {location_name} on {tomorrow}:\n"
                return header + "\n".join(descriptions)

    except requests.exceptions.RequestException as e:
        return f"Error fetching data: {e}" if desc else -1.0
    except KeyError:
        return "Error parsing data." if desc else -1.0

# --- Main execution ---
if __name__ == "__main__":
    # ⚠️ IMPORTANT: Using the API key from your previous code
    API_KEY = "eddbc7c0c9e63e225934add809624c6e"
    
    # Example coordinates for Mumbai, India
    LATITUDE = 19.0760
    LONGITUDE = 72.8777
    
    # --- Test Case 1: With Description (desc=True) ---
    print("--- Fetching with Description (the default) ---")
    description_output = get_rain_forecast(API_KEY, LATITUDE, LONGITUDE, desc=True)
    print(description_output)
    
    print("\n" + "="*50 + "\n")

    # --- Test Case 2: Numerical Value Only (desc=False) ---
    print("--- Fetching Total Rain Value Only ---")
    value_output = get_rain_forecast(API_KEY, LATITUDE, LONGITUDE, desc=False)
    print(f"Total expected rain for tomorrow: {value_output} mm")