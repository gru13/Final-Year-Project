import requests
import pandas as pd
import numpy as np
import os
from datetime import datetime, timezone, timedelta
from collections import defaultdict
from typing import Optional, Dict

def get_co2(start_date_str: str, end_date_str: str, filename: str = 'co2_daily_mlo.txt') -> pd.DataFrame:
    """Fetches daily CO2 data from NOAA."""
    DATA_URL = 'https://gml.noaa.gov/webdata/ccgg/trends/co2/co2_daily_mlo.txt'
    req_start_date = pd.to_datetime(start_date_str)
    req_end_date = pd.to_datetime(end_date_str)
    
    download_needed = True
    df = pd.DataFrame()

    if os.path.exists(filename):
        try:
            df = _read_noaa_file(filename)
            local_min_date = df['date'].min()
            local_max_date = df['date'].max()
            if req_start_date >= local_min_date and req_end_date <= local_max_date:
                download_needed = False
        except (pd.errors.EmptyDataError, KeyError, IndexError):
            pass

    if download_needed:
        try:
            response = requests.get(DATA_URL, timeout=15)
            response.raise_for_status()
            with open(filename, 'w', encoding='utf-8') as file:
                file.write(response.text)
            df = _read_noaa_file(filename)
        except requests.exceptions.RequestException:
            return pd.DataFrame()

    if not df.empty:
        mask = (df['date'] >= req_start_date) & (df['date'] <= req_end_date)
        return df.loc[mask, ['date', 'ppm']].reset_index(drop=True)
    
    return pd.DataFrame()

def _read_noaa_file(filepath: str) -> pd.DataFrame:
    """Helper function to read and parse the NOAA data file."""
    df = pd.read_csv(filepath, comment="#", sep=r'\s+', names=["yr", "mon", "day", "decimal", "ppm"])
    df['date'] = pd.to_datetime(df[['yr', 'mon', 'day']].rename(columns={'yr': 'year', 'mon': 'month', 'day': 'day'}))
    return df

def get_o3(api_key: str, lat: float, lon: float, start_str: str, end_str: str) -> pd.DataFrame:
    """Fetches O3 data from OpenWeatherMap API."""
    if not api_key or api_key == "YOUR_API_KEY_HERE":
        return pd.DataFrame()

    try:
        start_dt = datetime.strptime(start_str, "%Y-%m-%d")
        end_dt = datetime.strptime(end_str, "%Y-%m-%d").replace(hour=23, minute=59, second=59)
        start_ts = int(start_dt.replace(tzinfo=timezone.utc).timestamp())
        end_ts = int(end_dt.replace(tzinfo=timezone.utc).timestamp())

        api_url = f"http://api.openweathermap.org/data/2.5/air_pollution/history?lat={lat}&lon={lon}&start={start_ts}&end={end_ts}&appid={api_key}"
        
        response = requests.get(api_url)
        response.raise_for_status()
        data = response.json()

        if 'list' not in data or not data['list']:
            return pd.DataFrame()
        
        daily_data = defaultdict(list)
        for entry in data['list']:
            local_date = datetime.fromtimestamp(entry['dt'], tz=timezone(timedelta(hours=5, minutes=30))).date()
            daily_data[local_date].append(entry['components'].get('o3', 0))

        records = [{'date': date, 'OZON7': sum(vals) / len(vals)} for date, vals in sorted(daily_data.items())]
        return pd.DataFrame(records) if records else pd.DataFrame()

    except (requests.exceptions.RequestException, KeyError, IndexError, ZeroDivisionError):
        return pd.DataFrame()

def _fetch_nasa_weather(lat, lon, start, end):
    """Fetches NASA POWER weather data."""
    try:
        url = "https://power.larc.nasa.gov/api/temporal/daily/point"
        params = {
            "start": pd.to_datetime(start).strftime("%Y%m%d"),
            "end": pd.to_datetime(end).strftime("%Y%m%d"),
            "latitude": lat, "longitude": lon, "community": "AG",
            "parameters": "ALLSKY_SFC_SW_DWN,T2M_MAX,T2M_MIN,T2MDEW,PRECTOTCORR,WS2M,RH2M,EVPTRNS",
            "format": "JSON"
        }
        response = requests.get(url, params=params).json()
        data = response["properties"]["parameter"]
        
        df = pd.DataFrame(data).reset_index().rename(columns={"index": "date"})
        df["date"] = pd.to_datetime(df["date"], format="%Y%m%d")
        
        df = df.rename(columns={
            "ALLSKY_SFC_SW_DWN":"srad", "T2M_MAX":"tmax", "T2M_MIN":"tmin", "T2MDEW":"dewp",
            "PRECTOTCORR":"rain", "WS2M":"wind", "RH2M":"rhum", "EVPTRNS":"evap"
        })
        return df
    except Exception:
        return pd.DataFrame()

def create_weather_file(
    api_key: str, 
    lat: float, 
    lon: float, 
    start_date: str, 
    end_date: str, 
    site_name: str = "SITE", 
    insi: str = "XXXX", 
    elev: Optional[float] = None
) -> Optional[pd.DataFrame]:
    """
    Fetches weather, CO2, and O3 data, merges them, and writes a DSSAT-compatible .WTH file.
    """
    # Fetch all data
    weather_df = _fetch_nasa_weather(lat, lon, start_date, end_date)
    co2_df = get_co2(start_date, end_date)
    o3_df = get_o3(api_key, lat, lon, start_date, end_date)

    if weather_df.empty:
        return None

    # Merge data
    df = weather_df
    
    if not co2_df.empty:
        df = pd.merge(df, co2_df, on='date', how='left')
        df = df.rename(columns={"ppm": "dco2"})
    
    if not o3_df.empty:
        o3_df['date'] = pd.to_datetime(o3_df['date'])
        df = pd.merge(df, o3_df, on='date', how='left')
        df = df.rename(columns={"OZON7": "ozon7"})

    # Fill missing values - fix the type annotation issue
    if 'dco2' not in df.columns:
        df['dco2'] = 421.0
    else:
        df['dco2'] = df['dco2'].fillna(421.0)
    
    if 'ozon7' not in df.columns:
        df['ozon7'] = 50
    else:
        df['ozon7'] = df['ozon7'].fillna(50)

    # Calculations
    df["wind"] = df["wind"] * 86.4  # m/s → km/day
    df["month"] = df["date"].dt.month
    monthly_srad_avg: Dict[int, float] = df.groupby("month")["srad"].mean().to_dict()
    df["par"] = df["month"].map(monthly_srad_avg)
    df["vapr"] = 0.6108 * np.exp((17.27 * df["dewp"]) / (df["dewp"] + 237.3))
    df["YRDOY"] = df["date"].dt.strftime("%y%j")
    
    tav = ((df["tmax"] + df["tmin"]) / 2).mean()
    amp = (df["tmax"].mean() - df["tmin"].mean())

    # Prepare output data
    df_out = df[["YRDOY","srad","tmax","tmin","rain","rhum","wind",
                 "dewp","par","vapr","dco2","ozon7","evap"]]

    # Write file
    output_dir = "weather"
    os.makedirs(output_dir, exist_ok=True)
    start_yrdoy = df_out["YRDOY"].iloc[0]
    wth_file = os.path.join(output_dir, f"{insi}_{start_yrdoy}.WTH")

    with open(wth_file, "w") as f:
        f.write(f"*WEATHER DATA : {site_name},NASA\n\n")
        f.write("@ INSI      LAT     LONG   ELEV   TAV   AMP REFHT WNDHT   CCO2\n")
        f.write(f"  {insi:<4s}  {lat:7.3f} {lon:7.3f} {elev if elev else 100:5.1f}  {tav:5.1f}  {amp:5.1f}   2.0   2.0  {df['dco2'].mean():6.1f}\n\n")
        f.write("@  DATE  SRAD  TMAX  TMIN  RAIN  RHUM  WIND  DEWP   PAR  VAPR   DCO2  OZON7  EVAP\n")
        for _, row in df_out.iterrows():
            f.write(f"{int(row.YRDOY):7d} {row.srad:5.1f} {row.tmax:5.1f} {row.tmin:5.1f} "
                    f"{row.rain:5.1f} {row.rhum:5.1f} {row.wind:5.1f} {row.dewp:5.1f} "
                    f"{row.par:6.1f} {row.vapr:5.2f} {row.dco2:6.1f} {int(row.ozon7):6d} {row.evap:5.1f}\n")

    return df_out

if __name__ == "__main__":
    API_KEY = "eddbc7c0c9e63e225934add809624c6e"
    LATITUDE = 13.08
    LONGITUDE = 80.27
    START_DATE = "2025-01-01"
    END_DATE = "2025-03-31"
    
    final_data = create_weather_file(
        api_key=API_KEY,
        lat=LATITUDE,
        lon=LONGITUDE,
        start_date=START_DATE,
        end_date=END_DATE,
        site_name="CHENNAI",
        insi="IN01",
        elev=6.0
    )