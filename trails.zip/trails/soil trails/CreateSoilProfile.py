import logging
import sys
import time
from typing import List

import numpy as np
import pandas as pd
import requests



# Import the necessary classes AND the helper function from DSSATTools
from DSSATTools import SoilProfile, SoilLayer
from DSSATTools.soil import estimate_from_texture

# --- 1. SET YOUR INPUTS HERE ---
#---------------------------------
LATITUDE = 12.3811
LONGITUDE = 78.9366
COUNTRY = "India"
OUTPUT_FILENAME = "MY_GENERATED_SOIL.SOL"
#---------------------------------


# --- 2. HELPER FUNCTIONS ---

# --- Configuration Constants ---
SOILGRIDS_DEPTHS = ["0-5cm", "5-15cm", "15-30cm", "30-60cm", "60-100cm", "100-200cm"]
SOILGRIDS_PROPERTIES = [
    "sand", "silt", "clay", "bdod", "cfvo", "wv0033", "wv1500",
    "soc", "phh2o", "cec", "nitrogen"
]

def fetch_soilgrids_data_robust(latitude: float, longitude: float, properties: List[str], depths: List[str]) -> pd.DataFrame:
    """Fetches soil property data robustly with a retry mechanism."""
    logging.info(f"Fetching SoilGrids data for lat={latitude}, lon={longitude}")
    base_url = "https://rest.isric.org/soilgrids/v2.0/properties/query"
    all_properties_data = []
    max_retries = 4
    initial_retry_delay_seconds = 5

    for prop in properties:
        logging.info(f"--> Fetching property: {prop}")
        params = {'lon': longitude, 'lat': latitude, 'property': prop, 'depth': depths, 'value': 'mean'}
        for attempt in range(max_retries):
            try:
                response = requests.get(base_url, params=params, timeout=45)
                response.raise_for_status()
                data = response.json()
                layers = data.get('properties', {}).get('layers', [])
                if not layers:
                    logging.warning(f"No layer data for {prop}. Skipping.")
                    break
                parsed_data = {
                    depth_data['label']: depth_data.get('values', {}).get('mean', np.nan)
                    for depth_data in layers[0]['depths']
                }
                prop_df = pd.DataFrame.from_dict(parsed_data, orient='index', columns=[prop])
                all_properties_data.append(prop_df)
                time.sleep(1)
                break
            except requests.exceptions.HTTPError as e:
                if e.response.status_code == 429 and attempt < max_retries - 1:
                    wait_time = initial_retry_delay_seconds * (2 ** attempt)
                    logging.warning(f"Rate limit hit for '{prop}'. Retrying in {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    logging.error(f"HTTP error for '{prop}': {e}. It will be missing.")
                    break
            except (requests.exceptions.RequestException, ValueError, KeyError) as e:
                logging.error(f"Failed on property '{prop}': {e}. Skipping.")
                break
    if not all_properties_data:
        raise ValueError("Failed to fetch any data from SoilGrids.")
    final_df = pd.concat(all_properties_data, axis=1).reindex(depths)
    for prop in properties:
        if prop not in final_df.columns:
            final_df[prop] = np.nan
    return final_df

# --- UPDATED processing function ---
def process_and_estimate_dssat_format(raw_df: pd.DataFrame) -> pd.DataFrame:
    """
    Converts raw SoilGrids data and uses the DSSATTools `estimate_from_texture` 
    function to calculate hydraulic properties for each layer.
    """
    logging.info("Processing raw data and estimating hydraulic properties with DSSATTools...")
    
    # Initialize DataFrame with basic info
    dssat_df = pd.DataFrame(index=raw_df.index)
    dssat_df['SLB'] = [int(label.split('-')[1].replace('cm', '')) for label in raw_df.index]
    dssat_df['SLOC'] = raw_df['soc'] / 100
    dssat_df['SLNI'] = raw_df['nitrogen'] / 1000
    dssat_df['SLHW'] = raw_df['phh2o'] / 10
    dssat_df['SCEC'] = raw_df['cec'] / 10
    dssat_df['SLCF'] = raw_df['cfvo'] / 10
    
    # Define root growth factor
    rgf_map = {'0-5cm': 1.0, '5-15cm': 1.0, '15-30cm': 1.0, '30-60cm': 0.8, '60-100cm': 0.5, '100-200cm': 0.2}
    dssat_df['SRGF'] = dssat_df.index.map(rgf_map)
    
    # Loop through each layer to estimate properties
    for index, row in raw_df.iterrows():
        slcl = row['clay'] / 10
        slsi = row['silt'] / 10
        sbdm = row['bdod'] / 100
        
        dssat_df.loc[index, 'SLCL'] = slcl
        dssat_df.loc[index, 'SLSI'] = slsi
        dssat_df.loc[index, 'SBDM'] = sbdm

        if pd.notna(slcl) and pd.notna(slsi) and pd.notna(sbdm):
            # Use the library's built-in function to get consistent properties
            estimated_props = estimate_from_texture(slcl=slcl, slsi=slsi, sbdm=sbdm)
            dssat_df.loc[index, 'SLLL'] = estimated_props['slll']
            dssat_df.loc[index, 'SDUL'] = estimated_props['sdul']
            dssat_df.loc[index, 'SSAT'] = estimated_props['ssat']
            dssat_df.loc[index, 'SSKS'] = estimated_props['ssks']
        else:
            logging.warning(f"Missing texture/bulk density for layer {index}. Cannot estimate properties.")

    return dssat_df

def get_texture_class(sand: float, silt: float, clay: float) -> str:
    """Determines USDA soil texture class from sand, silt, clay percentages."""
    if (silt + 1.5 * clay) < 15: return 'S'
    if (silt + 1.5 * clay) >= 15 and (silt + 2 * clay) < 30: return 'LS'
    if (clay >= 7 and clay < 20) and (sand > 52) and ((silt + 2 * clay) >= 30): return 'SL'
    if (clay < 7) and (silt < 50) and ((silt + 2 * clay) >= 30): return 'SL'
    if (clay >= 7 and clay < 27) and (silt >= 28 and silt < 50) and (sand <= 52): return 'L'
    if (silt >= 50 and clay >= 12 and clay < 27): return 'SIL'
    if (silt >= 50 and clay < 12): return 'SI'
    if (silt >= 80 and clay < 12): return 'SI'
    if (clay >= 20 and clay < 35) and (silt < 28) and (sand > 45): return 'SCL'
    if (clay >= 27 and clay < 40) and (sand > 20 and sand <= 45): return 'CL'
    if (clay >= 27 and clay < 40) and (sand <= 20): return 'SICL'
    if (clay >= 35) and (sand > 45): return 'SC'
    if (clay >= 40) and (silt >= 40): return 'SIC'
    if (clay >= 40) and (sand <= 45) and (silt < 40): return 'C'
    return 'UNKNOWN'

def write_sol_file_with_dssattools(df: pd.DataFrame, lat: float, lon: float, country: str, filename: str):
    """
    Builds a SoilProfile object from the DataFrame and writes it to a file
    using the DSSATTools library classes.
    """
    logging.info(f"Building SoilProfile object with DSSATTools...")
    
    soil_layers = []
    for _, row in df.iterrows():
        kwargs = {k.lower(): v for k, v in row.to_dict().items()}
        kwargs = {k: v for k, v in kwargs.items() if pd.notna(v)}
        soil_layers.append(SoilLayer(**kwargs))

    top_layer = df.iloc[0]
    sand_pct = 100 - top_layer.get('SLCL', 0) - top_layer.get('SLSI', 0)
    texture = get_texture_class(sand_pct, top_layer.get('SLSI', 0), top_layer.get('SLCL', 0))
    soil_id = f"SG{str(int(abs(lat*100))):0>4}{str(int(abs(lon*100))):0>4}"
    
    soil_profile = SoilProfile(
        name=soil_id,
        soil_series_name='SoilGrids Auto-Generated Profile',
        soil_clasification=texture,
        site='SoilGrids',
        country=country,
        lat=lat,
        long=lon,
        salb=0.13, slu1=6.0, slro=75.0, sldr=-99, slnf=1.0, slpf=1.0,
        table=soil_layers
    )
    
    logging.info(f"Writing DSSAT .SOL file to {filename}")
    with open(filename, 'w') as f:
        f.write(soil_profile._write_sol())


# --- 3. MAIN EXECUTION LOGIC ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s', stream=sys.stdout)

try:
    raw_soil_data = fetch_soilgrids_data_robust(LATITUDE, LONGITUDE, SOILGRIDS_PROPERTIES, SOILGRIDS_DEPTHS)
    
    # Use the new, unified processing and estimation function
    final_dssat_profile = process_and_estimate_dssat_format(raw_soil_data)

    print("\n--- Final Processed DSSAT Data ---")
    print(final_dssat_profile.round(3).to_string())

    write_sol_file_with_dssattools(final_dssat_profile, LATITUDE, LONGITUDE, COUNTRY, OUTPUT_FILENAME)
    print(f"\n✅ Successfully created soil file using DSSATTools: {OUTPUT_FILENAME}")

    print(f"\nVerifying '{OUTPUT_FILENAME}'...")
    soil_id_to_check = f"SG{str(int(abs(LATITUDE*100))):0>4}{str(int(abs(LONGITUDE*100))):0>4}"
    verified_soil = SoilProfile.from_file(soil_id_to_check, OUTPUT_FILENAME)
    print("✅ Verification successful! The file can be read by DSSATTools.")

except Exception as e:
    logging.error(f"Script failed: {e}")