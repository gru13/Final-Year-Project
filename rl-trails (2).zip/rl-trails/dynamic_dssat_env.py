import gymnasium as gym
from gymnasium import spaces
import numpy as np
import pandas as pd
import os
import shutil
import time
from datetime import datetime, timedelta

# --- Import your custom file creation scripts ---
# Ensure these files are in the same directory or your Python path
from createSoilFile import create_soil_file
from createWeatherFile import create_weather_file

# --- Import DSSATTools ---
from DSSATTools import (
    crop, WeatherStation, SoilProfile, filex, DSSAT
)
from DSSATTools.filex import IrrigationEvent

class DynamicDSSATEnv(gym.Env):
    """
    A dynamic Gym environment for DSSAT that automatically generates
    soil and weather files for a given location and date range.

    **Action Space**: A continuous value representing the amount of irrigation
    water to apply in mm (e.g., any value between 0 and 50).

    **Observation Space (State)**: A 21-element vector containing key biophysical
    and environmental variables.

    **Reward Function**: A composite reward that encourages biomass growth and
    final yield while penalizing water cost, crop stress, and water drainage.
    """
    def __init__(self, lat, lon, start_date, end_date, planting_date,
                 workspace_dir, api_key=None, action_low=0.0, action_high=50.0):
        super(DynamicDSSATEnv, self).__init__()

        # --- 1. Store Core Parameters ---
        self.lat = lat
        self.lon = lon
        self.start_date = pd.to_datetime(start_date)
        self.end_date = pd.to_datetime(end_date)
        self.planting_date = pd.to_datetime(planting_date)
        self.workspace = workspace_dir
        self.api_key = api_key

        print(f"🌍 Initializing environment for Lat: {self.lat}, Lon: {self.lon}")

        # --- 2. Setup Workspace and Input Files ---
        self._setup_workspace_and_files()

        # --- 3. Define Action and Observation Spaces ---
        self.action_space = spaces.Box(low=np.array([action_low]), high=np.array([action_high]), dtype=np.float32)
        self.state_size = 21
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(self.state_size,), dtype=np.float32)

        # --- 4. Simulation Configuration (from dssat_env2.py) ---
        self.max_growth_days = 120
        self.reward_factors = {
            'GROWTH_FACTOR': 0.01,
            'WATER_COST_FACTOR': 0.1,
            'STRESS_PENALTY_FACTOR': 1.0,
            'DRAINAGE_PENALTY_FACTOR': 0.5,
            'DRYNESS_PENALTY_FACTOR': 0.5,
            'DRYNESS_THRESHOLD': 0.4,
        }

        # --- 5. Initialize DSSAT and Model Configs ---
        self._load_dssat_configs()
        self.dssat = DSSAT(self.workspace)
        print("✅ Environment setup complete.")


    def _setup_workspace_and_files(self):
        """
        Ensures the workspace and necessary DSSAT input files exist,
        generating them if they are not found.
        """
        os.makedirs(self.workspace, exist_ok=True)
        os.makedirs(os.path.join(self.workspace, "Weather"), exist_ok=True)
        print(f"📂 Using workspace: {self.workspace}")

        lat_str = str(int(abs(self.lat * 100))).zfill(4)
        lon_str = str(int(abs(self.lon * 100))).zfill(4)

        # --- Weather File Management ---
        self.insi = f"L{lat_str}L{lon_str}"[:4].upper()
        year_2_digit = self.start_date.strftime('%y')
        day_of_year = self.start_date.timetuple().tm_yday
        
        weather_filename = f"{self.insi}{year_2_digit}{day_of_year:02d}.WTH"
        
        self.weather_file_path = os.path.join(self.workspace, weather_filename)

        if not os.path.exists(self.weather_file_path):
            print(f"🌦️ Weather file not found. Generating '{weather_filename}'...")
            create_weather_file(
                lat=self.lat,
                lon=self.lon,
                start_date=self.start_date.strftime('%Y-%m-%d'),
                end_date=self.end_date.strftime('%Y-%m-%d'),
                wth_file_path=self.weather_file_path,
                api_key=self.api_key,
                insi=self.insi
            )
            print()
            shutil.copy(self.weather_file_path, os.path.join(os.path.join(self.workspace, f"Weather/{weather_filename}")))
        else:
            print(f"👍 Found existing weather file: '{weather_filename}'")
        
        # --- Soil File Management ---
        self.soil_id = f"SG{lat_str}{lon_str}"
        soil_filename = f"soil{lat_str}{lon_str}.SOL"
        self.soil_file_path = os.path.join(self.workspace, soil_filename)

        if not os.path.exists(self.soil_file_path):
            print(f"📜 Soil file not found. Generating '{soil_filename}'...")
            create_soil_file(
                lat=self.lat,
                lon=self.lon,
                output_dir=self.workspace,
                soil_id=self.soil_id,
                country="DynamicEnv"
            )
        else:
            print(f"👍 Found existing soil file: '{soil_filename}'")


    def _load_dssat_configs(self):
        """
        Loads the static DSSAT configuration objects using the dynamically
        set file paths and parameters.
        """
        # Hardcoded crop and cultivar as requested
        self.cultivar = crop.Sorghum('IB0026') #

        weather_station = WeatherStation.from_files([self.weather_file_path])
        self.soil_profile = SoilProfile.from_file(self.soil_id, self.soil_file_path)
        self.field = filex.Field(id_field='REALTIME', wsta=weather_station, id_soil=self.soil_profile)
        self.planting = filex.Planting(pdate=self.planting_date, ppop=18, ppoe=18, plrs=45, pldp=5)
        self.soil_depths = [int(layer['slb']) for layer in self.soil_profile.table]
        initial_values = [(depth, 0.20, 1.5, 1.5) for depth in self.soil_depths]
        self.initial_conditions = filex.InitialConditions(
            pcr='SG', icdat=self.planting_date, icres=1300, icren=0.5,
            table=pd.DataFrame(initial_values, columns=['icbl', 'sh2o', 'snh4', 'sno3'])
        )
        self.simulation_controls = filex.SimulationControls(
            general=filex.SCGeneral(sdate=self.planting_date),
            options=filex.SCOptions(water='Y', nitro='N', symbi='N'),
            methods=filex.SCMethods(infil='S'),
            management=filex.SCManagement(irrig='R', ferti='N', resid='N', harvs='M'),
            outputs=filex.SCOutputs(grout='Y', waout='Y', niout='Y', ovvew='Y')
        )

    # ====================================================================
    # The methods below are copied directly from dssat_env2.py
    # as their logic is independent of the file generation process.
    # ====================================================================

    def step(self, action):
        """
        Runs one daily time step of the environment's dynamics.
        """
        self.current_day += 1
        action_value = float(action[0])

        # Add an irrigation event to the schedule if the action is significant
        if action_value > 0.1:
            irr_date = self.planting_date + timedelta(days=self.current_day -1)
            event = IrrigationEvent(idate=irr_date, irop="IR001", irval=action_value)
            self.irrigation_events.append(event)

        # Re-run the simulation with the updated irrigation history
        self.dssat_output = self._run_simulation()

        # Handle simulation failures
        if self.dssat_output is None:
            # End the episode with a high penalty if simulation crashes
            return np.zeros(self.state_size), -200, True, True, {}

        current_state_dict = self._get_state(self.current_day)

        # Handle state extraction failures (e.g., simulation ended prematurely)
        if current_state_dict is None:
            # End the episode with a penalty
            return np.zeros(self.state_size), -100, True, True, {}

        reward = self._calculate_reward(self.previous_state, current_state_dict, action_value)
        
        # Check for termination conditions
        terminated = current_state_dict['phenological_stage'] >= 7
        truncated = self.current_day >= self.max_growth_days
        
        self.previous_state = current_state_dict
        observation = self._normalize_state(current_state_dict)

        return observation, reward, terminated, truncated, {}


    def reset(self, *, seed=None, options=None):
        """
        Resets the environment to an initial state for a new episode.
        """
        super().reset(seed=seed)
        self.current_day = 1
        self.irrigation_events = []
        self.dssat_output = self._run_simulation()

        if self.dssat_output is None:
            raise RuntimeError("Initial DSSAT simulation failed on reset. Check DSSAT setup.")

        self.previous_state = self._get_state(self.current_day)
        observation = self._normalize_state(self.previous_state)
        
        return observation, {}


    def _run_simulation(self):
        """Executes the DSSAT simulation with the current list of irrigation events."""
        irrigation = filex.Irrigation(
            efir=1, idep=30, iame='IR001', table=self.irrigation_events
        )
        try:
            self.dssat.run_treatment(
                field=self.field, cultivar=self.cultivar, planting=self.planting,
                initial_conditions=self.initial_conditions, irrigation=irrigation,
                simulation_controls=self.simulation_controls
            )
            return self.dssat.output_tables
        except Exception as e:
            # This helps debug issues with the DSSAT model itself
            print(f"❌ DSSAT Run Error on day {self.current_day}: {e}")
            return None

    def _get_state(self, current_day):
        """
        Extracts and calculates the state dictionary from DSSAT output.
        """
        try:
            if current_day not in self.dssat_output['PlantGro']['DAS'].values:
                return None
            
            soilwat_df = self.dssat_output['SoilWat']
            
            if 'DRNC_D' not in soilwat_df.columns:
                soilwat_df['DRNC_D'] = soilwat_df['DRNC'].diff().fillna(0)
                soilwat_df['DPREC'] = soilwat_df['PREC'].diff().fillna(soilwat_df['PREC'].iloc[0])
                soilwat_df['Rainfall7DaySum'] = soilwat_df['DPREC'].rolling(window=7, min_periods=1).sum()
                rain_mask = (soilwat_df['DPREC'] > 0).cumsum()
                soilwat_df['DaysSinceLastRain'] = soilwat_df.groupby(rain_mask).cumcount()

            current_weather = self.dssat_output['Weather'].loc[self.dssat_output['Weather']['DAS'] == current_day]
            current_plantgro = self.dssat_output['PlantGro'].loc[self.dssat_output['PlantGro']['DAS'] == current_day]
            current_soilwat = soilwat_df.loc[soilwat_df['DAS'] == current_day]

            def get_sw_by_depth(l, h):
                sw_cols = [c for c in soilwat_df.columns if c.startswith("SW") and c.endswith("D") and c[2:-1].isdigit()]
                vals = [current_soilwat[col].iloc[0] for col, depth in zip(sw_cols, self.soil_depths) if l < depth <= h]
                return np.mean(vals) if vals else 0.20

            days_since_last_irrigation = 0
            last_irr_event = None
            if self.irrigation_events:
                 last_irr_event = self.irrigation_events[-1]
                 days_since_last_irrigation = self.current_day - (last_irr_event.get('idate') - self.planting_date.date()).days
    
            last_irrigation_amount = last_irr_event.get('irval') if last_irr_event else 0

            try:
                forecast = float(soilwat_df.loc[soilwat_df['DAS'] == current_day + 1, 'DPREC'].iloc[0])
            except (IndexError, KeyError):
                forecast = 0.0

            state = {
                'DAP': current_day,
                'days_since_last_rain': current_soilwat['DaysSinceLastRain'].iloc[0],
                'rainfall_7day': current_soilwat['Rainfall7DaySum'].iloc[0],
                'HarvestIndex': current_plantgro['HIAD'].iloc[0],
                'phenological_stage': current_plantgro['GSTD'].iloc[0],
                'leaf_area_index': current_plantgro['LAID'].iloc[0],
                'total_biomass': current_plantgro['CWAD'].iloc[0],
                'soil_water_content_0_30cm': get_sw_by_depth(0, 30),
                'soil_water_content_30_60cm': get_sw_by_depth(30, 60),
                'soil_water_content_60_100cm': get_sw_by_depth(60, 100),
                'available_water_fraction': current_soilwat['SWXD'].iloc[0],
                'water_stress_factor': current_plantgro['WSGD'].iloc[0],
                'temperature_avg': current_weather['TAVD'].iloc[0],
                'solar_radiation': current_weather['SRAD'].iloc[0],
                'last_irrigation_amount': last_irrigation_amount,
                'days_since_last_irrigation': days_since_last_irrigation,
                'cumulative_irrigation': current_soilwat['IRRC'].iloc[0],
                'totalnumberIrrigation': current_soilwat['IR#C'].iloc[0],
                'forecast': forecast,
                'harverst_grain_weight': self.dssat_output['PlantGro']['GWAD'].iloc[-1],
                'daily_drainage': current_soilwat['DRNC_D'].iloc[0]
            }
            return state
        except (IndexError, KeyError) as e:
            print(f"📉 State extraction failed on day {current_day}: {e}")
            return None

    def _calculate_reward(self, prev_state, curr_state, action):
        """Calculates the reward for the current time step."""
        if not prev_state or not curr_state: return -10

        growth = (curr_state['total_biomass'] - prev_state.get('total_biomass', 0)) * self.reward_factors['GROWTH_FACTOR']
        bonus = curr_state['harverst_grain_weight'] / 100 if curr_state['phenological_stage'] >= 7 else 0
        cost = action * self.reward_factors['WATER_COST_FACTOR']
        stress = (1 - curr_state['water_stress_factor']) * self.reward_factors['STRESS_PENALTY_FACTOR']
        drainage = curr_state['daily_drainage'] * self.reward_factors['DRAINAGE_PENALTY_FACTOR']
        slll, sdul = self.soil_profile.table[0]['slll'], self.soil_profile.table[0]['sdul']
        pawf = (curr_state['soil_water_content_0_30cm'] - slll) / (sdul - slll) if sdul > slll else 0
        dryness = (self.reward_factors['DRYNESS_THRESHOLD'] - pawf) * self.reward_factors['DRYNESS_PENALTY_FACTOR'] if pawf < self.reward_factors['DRYNESS_THRESHOLD'] else 0
        
        return float(growth + bonus - (cost + stress + drainage + dryness))

    def _normalize_state(self, state_dict):
        """Normalizes the state dictionary into a flat numpy array for the agent."""
        if state_dict is None: return np.zeros(self.state_size)
        ordered_keys = sorted(state_dict.keys())
        state_vector = [state_dict[key] for key in ordered_keys]
        return np.array(state_vector, dtype=np.float32)


# ====================================================================
# Example Usage
# ====================================================================

if __name__ == "__main__":
    
    # --- Define Simulation Parameters ---
    LAT = 12.3811
    LON = 78.9366
    START_DATE = "2014-01-01"
    END_DATE = "2014-12-31"
    PLANTING_DATE = "2014-06-02"
    WORKSPACE = "./dynamic_env_workspace"
    # Optional: Replace with your actual key if you have one
    OWM_API_KEY = "eddbc7c0c9e63e225934add809624c6e"

    print("🚀 Initializing Dynamic DSSAT Environment...")
    env = DynamicDSSATEnv(
        lat=LAT,
        lon=LON,
        start_date=START_DATE,
        end_date=END_DATE,
        planting_date=PLANTING_DATE,
        workspace_dir=WORKSPACE,
        api_key=OWM_API_KEY
    )
    
    # print(f"\nAction Space: {env.action_space}")
    # print(f"Observation Space Shape: {env.observation_space.shape}")
    print("weather", env.weather_file_path)
    obs, info = env.reset()
    done = False
    truncated = False
    total_reward = 0
    day = 0
    
    start_time = time.time()
    print("\n--- Running a Test Episode with Random Actions ---")

    while not done and not truncated:
        day += 1
        action = env.action_space.sample()
        obs, reward, done, truncated, info = env.step(action)
        total_reward += reward
        
        print(f"Day: {day:03d} | "
              f"Action: {action[0]:5.2f} mm | "
              f"Reward: {reward:6.2f} | "
              f"Total Reward: {total_reward:8.2f}")
              
        if done:
            print("\n--- Episode Terminated (Harvest) ---")
        if truncated:
            print("\n--- Episode Truncated (Max Days Reached) ---")
            
    end_time = time.time()
    print(f"\nFinal Total Reward: {total_reward:.2f}")
    print(f"Total Episode Time: {end_time - start_time:.2f} seconds")
    if day > 0:
        print(f"Average Time per Day: {(end_time - start_time) / day:.3f} seconds")