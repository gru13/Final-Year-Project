import numpy as np
from stable_baselines3 import SAC
from randomized_dssat_env import RandomizedDSSATEnv  # Make sure this import is correct

# --- 1. DEFINE CONSTANTS FOR INFERENCE ---
# Path to your saved model file
MODEL_PATH = "./sac_dssat_model1.zip"
# MODEL_PATH = "sac_randomized_dssat_latest_model.zip"
# A new workspace for evaluation to keep it separate from training
WORKSPACE_EVAL = "./evaluation_workspace"
# Your OpenWeatherMap API key
OWM_API_KEY = "eddbc7c0c9e63e225934add809624c6e"

# --- 2. CREATE A DETERMINISTIC EVALUATION ENVIRONMENT ---
# For inference, you typically want a fixed environment to get a consistent
# measure of performance. We achieve this by setting the min and max of each range
# to the same value.
print("🌱 Initializing a specific environment for evaluation...")
EVAL_PARAMS = {
    'lat_range': (12.0, 12.0),          # Fixed latitude
    'lon_range': (77.0, 77.0),          # Fixed longitude
    'year_range': (2021, 2021),         # Fixed year
    'planting_day_range': (140, 140)    # Fixed planting day
}

eval_env = RandomizedDSSATEnv(
    parameter_ranges=EVAL_PARAMS,
    workspace_dir=WORKSPACE_EVAL,
    api_key=OWM_API_KEY
)

# --- 3. LOAD THE TRAINED AGENT ---
print(f"🧠 Loading trained model from {MODEL_PATH}...")
# The model is loaded with the evaluation environment
model = SAC.load(MODEL_PATH, env=eval_env)

# --- 4. RUN THE INFERENCE LOOP ---
print("\n🚀 Starting inference run...")
# Reset the environment to get the first observation
obs, info = eval_env.reset()

done = False
total_reward = 0.0
step_count = 0

while not done:
    # Get the action from the model
    # Using deterministic=True makes the agent exploit its learned policy
    # without adding any exploration noise, which is what you want for evaluation.
    action, _states = model.predict(obs, deterministic=True)

    # Apply the action to the environment
    obs, reward, terminated, truncated, info = eval_env.step(action)

    # The episode ends if terminated (e.g., agent succeeded/failed) or truncated (e.g., time limit)
    done = terminated or truncated

    # Print the results of this step
    print(f"Step: {step_count+1} | Action: {action} | Reward: {reward:.2f}")

    total_reward += reward
    step_count += 1

print("\n🏁 Inference finished!")
print(f"Total steps taken: {step_count}")
print(f"🏆 Total reward for the episode: {total_reward:.2f}")

# --- 5. CLEAN UP ---
# Always close the environment when you're done
eval_env.close()