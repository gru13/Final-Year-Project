
Of course! Here are the abbreviations used in the Python script, primarily related to the DSSAT (Decision Support System for Agrotechnology Transfer) model's soil profile parameters.

DSSAT Soil Profile Abbreviations
These are standard variable names used in DSSAT .SOL files to describe the properties of different soil layers.

SLB: Soil Layer Base or Soil Layer Bottom Depth - The depth from the soil surface to the bottom of a specific layer, measured in centimeters (cm).

SBDM: Soil Bulk Density, Moist - The oven-dry weight of soil per unit volume, measured in grams per cubic centimeter (g/cm 
3
 ).

SLOC: Soil Layer Organic Carbon - The percentage of organic carbon in the soil layer (weight basis), measured in percent (%).

SLNI: Soil Layer Nitrogen - The percentage of total nitrogen in the soil layer (weight basis), measured in percent (%).

SLCL: Soil Layer Clay - The percentage of clay particles (< 0.002 mm) in the soil layer, measured in percent (%).

SLSI: Soil Layer Silt - The percentage of silt particles (0.002–0.05 mm) in the soil layer, measured in percent (%).

SLCF: Soil Layer Coarse Fragments - The volumetric percentage of rock fragments or gravel in the layer, measured in percent (%).

SLHW: Soil Layer pH in Water - The soil pH measured in a water solution.

SCEC: Soil Cation Exchange Capacity - A measure of the soil's ability to hold positively charged ions, measured in centimoles per kilogram (cmol/kg).

SRGF: Soil Root Growth Factor - A factor from 0.0 to 1.0 indicating how favorable the soil layer is for root growth, with 1.0 being optimal.

SLLL: Soil Lower Limit of plant available moisture - Also known as the Wilting Point. It's the volumetric water content of the soil when plants can no longer extract water, measured in cubic centimeters of water per cubic centimeter of soil (cm 
3
 /cm 
3
 ).

SDUL: Soil Drained Upper Limit - Also known as Field Capacity. It's the volumetric water content of the soil after excess water has drained away, measured in cubic centimeters of water per cubic centimeter of soil (cm 
3
 /cm 
3
 ).

SSAT: Soil Saturated water content - The volumetric water content when all soil pores are filled with water, measured in cubic centimeters of water per cubic centimeter of soil (cm 
3
 /cm 
3
 ).

SSKS: Saturated Hydraulic Conductivity - A measure of how easily water moves through a saturated soil layer, measured in centimeters per hour (cm/hr).

SLDR: Soil Drainage Rate - A coefficient that describes the rate at which water drains from the soil profile.

SALB: Soil Albedo - The fraction of solar radiation reflected by the dry soil surface (a value between 0 and 1).

SLU1: Evaporation Limit - The cumulative amount of evaporation that can occur before the process switches from constant-rate to falling-rate evaporation, measured in millimeters (mm).

SLRO: Surface Runoff Curve Number - An empirical parameter used to predict direct runoff or infiltration from rainfall.

SoilGrids Abbreviations
These are abbreviations for the raw data properties fetched from the SoilGrids API.

bdod: Bulk density of the fine earth fraction

cfvo: Coarse fragments volumetric

wv0033: Water content at 0.033 MPa (This corresponds to Field Capacity or SDUL)

wv1500: Water content at 1.5 MPa (This corresponds to Wilting Point or SLLL)

soc: Soil organic carbon content

phh2o: Soil pH measured in water

cec: Cation Exchange Capacity

USDA Soil Texture Class Abbreviations
These are used in the _get_texture_class function to classify the soil.

S: Sand

LS: Loamy Sand

SL: Sandy Loam

L: Loam

SIL: Silt Loam

SI: Silt

SCL: Sandy Clay Loam

CL: Clay Loam

SICL: Silty Clay Loam

SC: Sandy Clay

SIC: Silty Clay

C: Clay





* **@YEAR**: Year
* **DOY**: Day of Year
* **DAS**: Days After Sowing
* **PRED**: Photoperiod (hours)
* **DAYLD**: Day Length (hours)
* **TWLD**: Twilight Day Length (for winter wheat) (hours)
* **SRAD**: Solar Radiation (MJ/m²/day)
* **PARD**: Photosynthetically Active Radiation (MJ/m²/day)
* **CLDD**: Cloudiness (%)
* **TMXD**: Maximum Air Temperature (°C)
* **TMND**: Minimum Air Temperature (°C)
* **TAVD**: Average Daily Air Temperature (°C)
* **TDYD**: Average Daytime Temperature (°C)
* **TDWD**: Wet Bulb Temperature (°C)
* **TGAD**: Average Canopy Temperature (°C)
* **TGRD**: Average Root Zone Temperature (°C)
* **WDSD**: Wind Speed (km/day)
* **CO2D**: CO2 Concentration (ppm)
* **VPDF**: Vapor Pressure Deficit (kPa)
* **VPD**: Vapor Pressure (kPa)
* **OZON7**: 7-hour Average Ozone Concentration (ppb)
* **WDATE**: Weather Date (in YYYYDOY format)

---
### ##💧 Soil Water (`current_soilwat`)
* **@YEAR**: Year
* **DOY**: Day of Year
* **DAS**: Days After Sowing
* **SWTD**: Total Soil Water in Profile (mm)
* **SWXD**: Extractable Soil Water in Profile for the plant (mm)
* **ROFC**: Cumulative Runoff (mm)
* **DRNC**: Cumulative Drainage (mm)
* **PREC**: Cumulative Precipitation (mm)
* **IR#C**: Cumulative Number of Irrigations
* **IRRC**: Cumulative Irrigation Amount (mm)
* **DTWT**: Depth to Water Table (cm)
* **MWTD**: Water Stress Factor for Photosynthesis
* **TDFD**: Daily Transpiration (mm)
* **TDFC**: Cumulative Transpiration (mm)
* **ROFD**: Daily Runoff (mm)
* **SW1D** to **SW10**: Soil Water in Layer 1 to 10 (cm³/cm³)
* **DAP**: Days After Planting

---
### ## 🌱 Plant Growth (`current_plantgro`)
* **@YEAR**: Year
* **DOY**: Day of Year
* **DAS**: Days After Sowing
* **DAP**: Days After Planting
* **L#SD**: Number of Live Leaves
* **GSTD**: Growth Stage (code for the plant's development stage)
* **LAID**: Leaf Area Index (m²/m²)
* **LWAD**: Leaf Weight (kg/ha)
* **SWAD**: Stem Weight (kg/ha)
* **GWAD**: Grain Weight (kg/ha)
* **RWAD**: Root Weight (kg/ha)
* **VWAD**: Vegetative Weight (Leaf + Stem) (kg/ha)
* **CWAD**: Canopy Weight (Total above-ground biomass) (kg/ha)
* **G#AD**: Number of Grains (per m² or per plant)
* **GWGD**: Individual Grain Weight (g)
* **HIAD**: Harvest Index
* **PWAD**: Panicle Weight (kg/ha)
* **P#AD**: Panicle Number (per m²)
* **WSPD**: Water Stress Factor for Photosynthesis (0-1 scale)
* **WSGD**: Water Stress Factor for Growth (0-1 scale)
* **NSTD**: Nitrogen Stress Factor for Photosynthesis (0-1 scale)
* **EWSD**: Evaporation Water Stress Factor
* **PST1A**, **PST2A**: Phosphorus Stress Factors
* **KSTD**: Potassium Stress Factor
* **LN%D**: Leaf Nitrogen Concentration (%)
* **SH%D**: Shell Nitrogen Concentration (%)
* **HIPD**: Harvest Index at Physiological Maturity
* **PWDD**: Pod Weight (kg/ha)
* **PWTD**: Tuber Weight (kg/ha)
* **SLAD**: Specific Leaf Area (cm²/g)
* **CHTD**: Canopy Height (cm)
* **CWID**: Canopy Width (cm)
* **RDPD**: Root Depth (cm)
* **RL1D** to **RL10D**: Root Length Density in Layer 1 to 10 (cm/cm³)
* **CDAD**: Daily Change in Canopy Weight (kg/ha/day)
* **LDAD**: Daily Change in Leaf Weight (kg/ha/day)
* **SDAD**: Daily Change in Stem Weight (kg/ha/day)
* **SNW0C**, **SNW1C**: Snow Water Content variables
* **DTTD**: Daily Thermal Time (same as daily GDD) (°C-day)

---
### ## 🍂 Soil Organics (`current_soilorg`)
* **@YEAR**: Year
* **DOY**: Day of Year
* **DAS**: Days After Sowing
* **OMAC**: Cumulative Organic Matter Mineralization (kg/ha)
* **SCDD**: Daily Soil Carbon Change (kg/ha)
* **SOCD**: Soil Organic Carbon in profile (kg/ha)
* **SC0D**, **SCTD**: Soil Carbon in different pools
* **SOMCT**: Total Soil Organic Matter Carbon (t/ha)
* **LCTD**: Litter Carbon (kg C/ha)
* **ONAC**: Cumulative Organic Nitrogen Mineralization (kg N/ha)
* **SNDD**: Daily Soil Nitrogen Change (kg N/ha)
* **SOND**: Soil Organic Nitrogen in profile (kg N/ha)
* **SN0D**, **SNTD**: Soil Nitrogen in different pools
* **SOMNT**: Total Soil Organic Matter Nitrogen (t/ha)
* **LNTD**: Litter Nitrogen (kg N/ha)
